const RequiredAuth = ({ children }) => {
  return children;
};

export default RequiredAuth;
