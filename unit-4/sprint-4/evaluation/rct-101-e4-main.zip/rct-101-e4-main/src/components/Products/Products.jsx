import React from "react";

const Products = () => {
  return <div>{/* here */}</div>;
};

export default Products;
