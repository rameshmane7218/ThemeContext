export const AUTH_SIGN_IN_LOADING = "auth/signin/loading";
export const AUTH_SIGN_IN_SUCCESS = "auth/signin/success";
export const AUTH_SIGN_IN_ERROR = "auth/signin/error";
export const AUTH_SIGN_OUT = "auth/signout";
