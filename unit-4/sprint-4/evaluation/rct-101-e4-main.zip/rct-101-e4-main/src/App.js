import "./App.css";

function App() {
  return <div className="App">{/* code here */}</div>;
}

export default App;
