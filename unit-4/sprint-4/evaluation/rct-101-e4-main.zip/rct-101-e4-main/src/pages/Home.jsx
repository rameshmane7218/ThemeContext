import React from "react";

const Home = () => {
  return <div>{/* code here */}</div>;
};

export default Home;
